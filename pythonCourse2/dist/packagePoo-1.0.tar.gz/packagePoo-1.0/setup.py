from setuptools import setup

setup(
   name="packagePoo",
   version="1.0",
   description="Package of POO",
   author="Emir Zahir",
   author_email="emir@hotmail.com",
   url="www.linkedin.com",
   packages=["poo"]

)
